<div class="col-12 padding-sidenav px-0 pr-md-0">
	<div class="topnav">
		<h2 class="formheader">Admin 1</h2>
		<input type="search" name="search" class="search" placeholder="Search...">

		<div class="user">
			<!-- <a href="" class="wallet mr-3">Wallet</a> -->
			<!-- <div>
							<a href="" class="fa fa-user-circle-o"></a>
							<ul class="btn btn-secondary dropdown-menu">
								<li><a href="" class="dropdown-item"></a></li>
								<li><a href="" class="dropdown-item"></a></li>
								<li><a href="" class="dropdown-item"></a></li>
							</ul>
						</div> -->
			<div class="btn-group">
				<button type="button" class="fa fa-user-circle-o dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
				</button>
				<div class="dropdown-menu">
					<a class="dropdown-item" href="#">Profile</a>
					<a class="dropdown-item" href="#">Wallet: Rs 232</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="logout_admin.php">Log Out</a>
				</div>
			</div>
		</div>
	</div>
</div>